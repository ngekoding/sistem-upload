/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Anime;

/**
 *
 * @author N
 */
public class Main {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insertFirst("Naruto", "Mashashi Kishimoto");
        list.insertFirst("One Piece", "Oichiro Oda");
        list.insertLast("Bleach", "Tite Kubo");
        list.insertLast("Dragon Ball", "Akira Toriyama");
        list.insertAt("Fairy Tale", "Hiro Mashima", "Naruto");
        list.deleteAt("Naruto");
        list.print();
    }
    
}
