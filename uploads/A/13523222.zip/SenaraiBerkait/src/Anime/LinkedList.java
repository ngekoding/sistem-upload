/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Anime;

/**
 *
 * @author N
 */
public class LinkedList {
    Elemen first;
    
    //konstruktor
    public LinkedList(){
        this.first = null;
    }
    
    public void insertFirst(String judul, String pengarang){
        Elemen _elemen = new Elemen(judul,pengarang);
        _elemen.next = this.first;
        this.first = _elemen;
    }
    
    public void insertLast(String judul, String pengarang){
      Elemen _elemen = new Elemen(judul,pengarang);
      if(first == null){
          this.first = _elemen;
      }else{
          Elemen last = this.first; // pointer yg akan bergerak untuk menemukan elemen terakhir
          while(last.next != null){
              last = last.next;
          }
          last.next = _elemen;
      }
    }
    
    public void insertAt(String judul, String pengarang, String _el){
        Elemen _elemen = new Elemen(judul,pengarang);
        if(first == null){
            this.first = _elemen;
        }else{
            Elemen pointer = first; //pointer yg akan bergerak untuk enemukan elemen yg mengandung info berupa _el
            while(pointer.next != null){
                if(pointer._info.judul.equals(_el)){
                    _elemen.next = pointer.next;
                    pointer.next = _elemen;
                }
                pointer = pointer.next;
            }
        }
    }
    
    
    public void deleteFirst(){
        if(first == null) System.out.println("List is already Empty");
        else first = first.next;
    }
    
    public void deleteLast(){
        if(first == null){
            System.out.println("List is already Empty");
        }else{
            Elemen last = first; //pointer yg akan bergerak untuk menemukan elemen terakhir
            Elemen befLast = null; // pointer yg akan berada pada elemen sebelum elemen terakhit
            while(last.next != null){
                befLast = last;
                last = last.next;
            }
            befLast.next = null;
        }
    }
    
    public void deleteAt(String _el){
        if(first == null){
            System.out.println("List is already Empty");
        }else{
            Elemen pointer = first; // pointer yg akan bergerak untuk menemukan elemen dengan informasi _el
            Elemen bef_el = null; // pointer yang akan berada pada elemen sebelum elemen pointer
            while(pointer.next != null){
                bef_el = pointer;
                pointer = pointer.next;
                if(pointer._info.judul.equals(_el)){
                    bef_el.next = pointer.next;
                }
            }
        }
        
    }
    
    public void print(){
        Elemen _elemen = first;
        if(_elemen == null) System.out.println("List is Empty");
        else{
            while(_elemen != null){
                System.out.println(_elemen._info.judul+" - "+_elemen._info.pengarang);
                _elemen = _elemen.next;
            }
        }
    }
    
}
