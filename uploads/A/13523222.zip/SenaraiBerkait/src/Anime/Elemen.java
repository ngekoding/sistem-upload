/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Anime;

/**
 *
 * @author N
 */
public class Elemen {
    Info _info;
    Elemen next;
    
    public Elemen(String judul, String pengarang){
        this._info = new Info(judul,pengarang);
        this.next = null;
    }
    
}
