/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Anime;

/**
 *
 * @author N
 */
public class Info {
    public String judul, pengarang;
    
    public Info(String judul, String pengarang){
       this.judul = judul;
       this.pengarang = pengarang;
    }
    
}
