<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "inf";

$connect = mysqli_connect($host, $user, $pass, $db) or die(mysqli_error());